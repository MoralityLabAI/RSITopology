# RSI Topology: Spectral-Bundle Discovery

This repository turns the JSpace harmonic/global-section diagnostic into a
bounded discovery program for high-dimensional structures. The current object
is not graph topology by itself and not a guessed coordinate tuple. It is a
stable spectral bundle: a high-occupancy eigenspace of the mean projector for
a frozen band of prompt-specific, reliability-weighted sheaf Laplacians.

Two downstream hypotheses are kept separate:

1. **RL allocation:** energy in the frozen bundle improves held-out prediction
   and supports a candidate-sampling tilt whose KL divergence from the base
   policy is capped.
2. **Coordinated edits:** signed coordinates in the bundle improve held-out
   prediction beyond nuisance variables and Jacobian visibility, and beat a
   matched-rank Haar subspace. Discovery emits a normalized proposal and hash;
   it does not apply the edit.

Run the CPU synthetic controls:

```powershell
python scripts/run_synthetic_discovery.py
python -m pytest -q
```

The real-model input contract is a family of prompt-specific normalized
weighted Laplacian operators acting on one registered edit space, candidate
vectors generated without outcomes, baseline nuisance/Jacobian covariates,
independent prompt/run groups, and outcomes joined only after geometry is
sealed. The existing JSpace protocol supplies the operator/reveal half.

No live model training or weight mutation is authorized by this repository.
The June Research_Engine edit receipts lack the actual edit matrices and
source provenance required to reconstruct the geometry; they may inform power
planning but cannot validate the edit gate retrospectively.

Current engineering protocol: `protocols/spectral_bundle_discovery_v0_2.json`.
The v0.1 protocol and its absolute-uplift failure remain preserved. Large or
model-bearing runs are currently blocked by
`reports/resource_enforcement_audit.md`; only unit-scale controls are allowed
until CPU and I/O cgroups are delegated or an approved container path exists.

Prepare (but do not execute) the next one-prompt benchmark by copying
`protocols/one_prompt_run_registration_template.json`, filling every required
hash/cap, then freezing it with:

```powershell
python scripts/register_one_prompt_benchmark.py completed.json --out-dir artifacts/one_prompt_registered
```

The registration prohibits outcomes and weight mutation. Its successful gates
authorize only a later multi-prompt prereveal engineering run.
