from __future__ import annotations

import pytest

from rsi_topology.attestation import AnchorRegistry
from rsi_topology.vpd_stratification import analyze_stratified_outcomes, seal_identity_strata
from test_attestation import make_record


def feature(candidate, pair, arm, replicate):
    return {
        "candidate_id": candidate,
        "pair_id": pair,
        "arm": arm,
        "site_id": "layer.12.mlp",
        "run_replicate": replicate,
        "prompt_group": f"prompt-{replicate}",
        "family": "factual_recall",
        "norm": 0.5,
        "rank": 2,
    }


def test_seal_and_analyze_only_within_identity_strata():
    registry = AnchorRegistry(records=[make_record()])
    features = [
        feature("c1", "p1", "intervention", "r1"),
        feature("c2", "p1", "matched_random", "r1"),
        feature("c3", "p2", "intervention", "r2"),
        feature("c4", "p2", "matched_random", "r2"),
    ]
    sealed, registration = seal_identity_strata(features, registry)
    assert registration["outcomes_present"] is False
    assert all(row["identity_stratum"] == "holonomy_clean" for row in sealed)
    outcomes = [
        {"candidate_id": "c1", "accepted": 1, "repair_auc": 0.8, "initial_decay": 0.4},
        {"candidate_id": "c2", "accepted": 0, "repair_auc": 0.2, "initial_decay": 0.1},
        {"candidate_id": "c3", "accepted": 1, "repair_auc": 0.7, "initial_decay": 0.3},
        {"candidate_id": "c4", "accepted": 0, "repair_auc": 0.1, "initial_decay": 0.0},
    ]
    result = analyze_stratified_outcomes(sealed, outcomes, registration)
    assert result["pooled_effect"] == "prohibited"
    assert set(result["strata"]) == {"holonomy_clean"}
    assert result["strata"]["holonomy_clean"]["accepted"]["mean_paired_difference"] == 1.0


def test_reveal_rejects_bad_id_universe_and_broken_pair():
    registry = AnchorRegistry(records=[make_record()])
    features = [
        feature("c1", "p1", "intervention", "r1"),
        feature("c2", "p1", "matched_random", "r1"),
    ]
    sealed, registration = seal_identity_strata(features, registry)
    with pytest.raises(ValueError, match="universe mismatch"):
        analyze_stratified_outcomes(
            sealed,
            [{"candidate_id": "c1", "accepted": 1, "repair_auc": 0.8, "initial_decay": 0.4}],
            registration,
        )
    features[1]["rank"] = 4
    with pytest.raises(ValueError, match="not matched on rank"):
        seal_identity_strata(features, registry)
