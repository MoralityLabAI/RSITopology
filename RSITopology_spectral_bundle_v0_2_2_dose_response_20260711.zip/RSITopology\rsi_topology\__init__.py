"""Spectral-bundle discovery for bounded self-improvement experiments."""

from .discovery import (
    ConsensusBand,
    DiscoveryConfig,
    DiscoveryResult,
    discover_consensus_bands,
    evaluate_discovery,
    subspace_lineage,
)
from .jspace_bridge import load_operator_bundle, write_operator_bundle

__all__ = [
    "ConsensusBand",
    "DiscoveryConfig",
    "DiscoveryResult",
    "discover_consensus_bands",
    "evaluate_discovery",
    "subspace_lineage",
    "load_operator_bundle",
    "write_operator_bundle",
]
