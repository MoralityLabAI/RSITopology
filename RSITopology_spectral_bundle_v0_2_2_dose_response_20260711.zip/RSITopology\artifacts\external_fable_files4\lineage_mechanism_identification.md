# Mechanism Identification: The 0.35→0.5 Transition Is Band Failover

External diagnostic, same evidence class as the prior Fable imports. Probe
data in `lineage_mechanism_probe.json`; all runs on the lineage-bundle code
(11 tests passing, archive SHA-256 `53B998EB...750441` verified).

## Resolution

The hypothesis doc left the mechanism open among four candidates. It is now
identified, three seeds, ground truth via `planted_basis`:

At noise 0.5 the mean projector's top eigenspace remains ~95% planted-aligned;
its occupancy spectrum has slid to [0.61, 0.80], leaving only 3 directions
above ρ=0.75. The low band therefore FAILS the geometry gate (rank 3 < 8).
The frozen lowest-band-meeting-the-gate rule then promotes the MIDDLE band:
rank 11–12, min occupancy ~0.751, planted overlap 0.014–0.020.

| seed     | low band          | planted ovl | middle band        | planted ovl |
|----------|-------------------|-------------|--------------------|-------------|
| 20260711 | rank 3, occ 0.758 | 0.948       | rank 12, occ 0.751 | 0.016       |
| 20260712 | rank 3, occ 0.765 | 0.945       | rank 11, occ 0.753 | 0.014       |
| 20260713 | rank 3, occ 0.771 | 0.945       | rank 12, occ 0.751 | 0.020       |

The 73.4% utility collapse follows immediately: the certified subspace at 0.5
is the middle band, which carries no outcome signal by construction. The
receipt recorded `selected_band: "middle"` throughout; the sweep summaries
(Fable's original and the transition analysis derived from it) read rank and
occupancy off the selected band without reading its name. "Rank remains 12"
was failover masking a collapse to rank 3.

## What this deflates and what it validates

Deflates: on this fixture, "coherence is not identity" is not subtle
within-structure migration. The selection rule certified a different
structure and the summary layer did not say so. The complete detector for
this mechanism is categorical: `selected_band != reference_selected_band`.
No Grassmannian machinery required.

Validates: the lineage statistic detected the swap at full magnitude
(chordal 0.016, max principal angle ~90°, worst retention ~0.0002) without
access to band labels, tracking planted-basis ground truth to three decimal
places (reference at smallest positive noise ≈ planted, per the frozen
reference rule). Band failover is one discrete instance of the general
failure lineage measures; a real model's identity change need not respect
frozen band boundaries. The categorical check catches this fixture's
mechanism only.

Unexercised: within-band identity migration never occurred here — the low
band's surviving directions stayed 0.95 planted-aligned even at 0.5. The
lineage protocol's claim of added value beyond cheap checks therefore rests
on the "occupancy-matched low-lineage construction" control, which should be
built to migrate identity WITHIN a band at held rank and occupancy. Until
that fixture exists, lineage is validated as a detector of band failover
(where the categorical check is cheaper) and untested on the failure mode
that motivates it.

## Recommended amendments (receipt-level, no gate changes)

1. Selection stability: geometry receipts record the selected band of the
   registered reference run; `selected_band` differing from it emits a
   mandatory warning and makes lineage feature serialization mandatory for
   that run. Failover runs are engineering evidence pending lineage review.
2. Margin attribution: `consensus_occupancy_margin` and its warning are
   reported per selected band WITH the band name; a healthy margin on a
   failover band is the exact signature that misled both summary layers.
3. Sweep summaries derived from receipts must carry `selected_band` as a
   grouping key. One-line change to the standing calibration runner.
4. Hypothesis-doc correction: "rank remains essentially unchanged" should be
   restated as selected-band rank under failover; low-band rank went 12→3.

## Boundary

Ground-truth overlap uses `planted_basis` and is synthetic-mechanism-probe
evidence only; it is unavailable and prohibited as a feature in real runs.
The target-blind protocol statistics remain the deployable object. Nothing
here amends v0.2.1 gates or the lineage follow-up's frozen evaluation.
