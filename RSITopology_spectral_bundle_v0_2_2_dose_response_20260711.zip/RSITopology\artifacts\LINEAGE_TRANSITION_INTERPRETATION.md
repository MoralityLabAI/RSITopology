# Lineage transition interpretation amendment

`lineage_transition_analysis.json` correctly identifies three replicated
geometry-pass/utility-collapse transitions in the imported scalar summary. It
cannot identify their mechanism because that source summary omitted
`selected_band`.

The later external mechanism probe established that all three transitions are
low-to-middle band failover. The prior phrase "rank essentially unchanged"
referred to selected-band rank and was misleading: low-band rank fell from 12
to 3. For this fixture, categorical selection stability is the cheapest
complete detector. See `reports/files4_mechanism_review.md`.
