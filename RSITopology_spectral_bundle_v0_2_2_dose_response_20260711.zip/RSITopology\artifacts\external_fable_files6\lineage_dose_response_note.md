# Lineage Dose-Response on the Identity-Rotation Control

External diagnostic on the v0.2.2 bundle (archive SHA-256
`F7046C84A7288B95ACFC8131243522BB5F5DF5C1C6D69160CD7D9471B83F514A`,
14 tests passing). Cold reproduction of
`lineage_identity_control_unit.json` agreed to 1-2 ulps on all
solver-derived quantities — within the v0.2.1 cross-environment tolerance
of 1e-4; environment stamps make the residual drift adjudicable.

Sweep: `lineage_rotation_radians` over 0-90 degrees in 5-degree steps,
unit fixture (d=24, r=6, 4 contexts, seed 20260711), reference = the
theta=0 low-band consensus. Data in `lineage_dose_response.json`.

Findings:
1. Mean chordal lineage equals cos^2(theta) to ~4 decimals at every dose;
   the statistic measures the construction's analytic identity loss.
2. Minimum occupancy is 0.9884 at every dose, including both gate flips.
   Occupancy carries no information about graded identity rotation.
3. Gate survival is staged and monotone: policy gate fails between
   chordal 0.82 and 0.75; edit gate between 0.50 and 0.41. Policy uplift
   declines near-linearly with lineage until ~50 degrees.
4. Leading-indicator window: lineage departure is unambiguous at 5
   degrees; first gate failure at 30. Continuous identity loss is
   measurable well before it is fatal — the complement of the band-failover
   mechanism, which was discontinuous and categorical. The two mechanisms
   bracket the failure space; lineage detects both, occupancy neither.
5. Noise floor: at 80-90 degrees the standardized uplift reads spurious
   values near +0.05 on a causally empty feature. On a fixture this size
   the 0.10 policy gate has ~2x headroom over noise.

Boundaries: one seed, unit scale, 5-degree grid. The gate-flip lineage
levels are fixture constants, not thresholds; the follow-up protocol's
prohibition on outcome-tuned gates applies. The sweep establishes shape
(monotone, near-linear, no cliff) as the registered-run prior, nothing
more. Suggested repo action: add the theta-sweep beside the binary
control in the standing calibration runner, 3+ seeds, receipts
band-attributed per v0.2.2.
