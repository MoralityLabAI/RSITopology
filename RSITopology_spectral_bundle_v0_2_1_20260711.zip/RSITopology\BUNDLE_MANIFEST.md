# RSI Topology spectral-bundle bundle

This bundle contains the mathematical program, v0.1/v0.2 protocols, JSpace
CSR bridge, synthetic and sparse controls, one-prompt registration template,
resource-enforcement probes, and all generated receipts. The `tmp/` PDF/tool
scratch tree, Python caches, and failed WSL virtual environment are excluded.

Scientific boundary: no model weights were changed and no outcome-bearing real
model run was completed. The invalidated Windows bridge receipt and WSL cap
probes are retained because they document the enforcement audit.

Verification at packaging: `python -m pytest -q` passed 10 tests in the local
unit suite. Promotion runs remain blocked until CPU and I/O cgroups are
delegated or an approved container runtime is available.
