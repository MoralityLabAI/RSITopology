# Qwen soft-atlas measurement gate v1

## Result

Measurement component: **fail**.
Prompt-scale component: **unavailable_insufficient_prompt_families**.
Overall G1 decision: **not_evaluated**.
Prompt-corpus decision: **do_not_invest_stop_branch**.

The measurement instrument uses only target-blind Qwen functional signatures. It works in the shared 12-dimensional probe-response space and does not identify coordinated weight-space edit coordinates.

## Frozen measurements

- lambda_measurement: `0.169414974217`
- registered edges: `112`
- effective-dimension range in central window: `4.343180`
- simultaneous-band common-intersection margin: `-3.100099`
- minimum observed-minus-null similarity margin: `-0.094024`
- minimum informative fraction: `1.000000`
- minimum median spectral anisotropy: `0.421853`
- audit-null false-support rate: `0.062256`

## Decision interpretation

The soft probe-response atlas fails at measurement scale. Stop before funding the prompt-corpus branch under this protocol.

The prior hard-projector `noise_floor_only` result is unchanged. A measurement pass would justify building a new prompt-family corpus, not opening recursive testing. A fail stops that investment under the frozen sequence.

## Claim boundary

This target-blind gate tests whether a gauge-invariant soft behavioral response geometry is stable above replica/checkpoint measurement noise in the existing Qwen3-1.7B primitives. It does not identify coordinated weight-space edits, use behavioral outcomes, authorize signed edits, measure recursive improvement, or establish RSI.
