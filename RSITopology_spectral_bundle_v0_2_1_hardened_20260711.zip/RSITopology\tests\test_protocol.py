from __future__ import annotations

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def load(name: str) -> dict:
    return json.loads((ROOT / "protocols" / name).read_text(encoding="utf-8"))


def test_v0_2_1_preserves_v0_2_primary_gates() -> None:
    old = load("spectral_bundle_discovery_v0_2.json")
    new = load("spectral_bundle_discovery_v0_2_1.json")

    assert new["amends"] == old["protocol_id"]
    assert new["primary_gates_unchanged"] is True
    assert new["geometry_gate"]["minimum_consensus_occupancy"] == old[
        "geometry_gate"
    ]["minimum_consensus_occupancy"]
    assert new["geometry_gate"]["minimum_consensus_rank"] == old["geometry_gate"][
        "minimum_consensus_rank"
    ]
    assert new["policy_gate"]["maximum_kl_from_uniform"] == old["policy_gate"][
        "maximum_kl_from_uniform"
    ]
    assert new["policy_gate"]["minimum_relative_mse_improvement"] == old[
        "policy_gate"
    ]["minimum_relative_mse_improvement"]
    assert new["policy_gate"]["minimum_standardized_heldout_return_uplift"] == old[
        "policy_gate"
    ]["minimum_standardized_heldout_return_uplift"]
    assert new["direct_edit_gate"] == old["direct_edit_gate"]
    assert "descriptive" in new["policy_gate"]["realized_ic"]
    assert "smallest positive" in new["standing_controls"][
        "sparse_geometry_noise"
    ]["rng_stream_note"]
