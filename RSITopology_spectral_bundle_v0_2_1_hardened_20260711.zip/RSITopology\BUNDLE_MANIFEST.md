# RSI Topology spectral-bundle bundle

This bundle contains the mathematical program, v0.1/v0.2/v0.2.1 protocols,
JSpace CSR bridge, synthetic and sparse controls, one-prompt registration
template, resource-enforcement probes, external Fable diagnostics with source
hashes, and all generated receipts. The `tmp/` PDF/tool scratch tree, Python
caches, prior packaging trees, and failed WSL virtual environment are excluded.

Scientific boundary: no model weights were changed and no outcome-bearing real
model run was completed. The invalidated Windows bridge receipt and WSL cap
probes are retained because they document the enforcement audit.

The final hardening records that sparse `geometry_noise=0` is a legacy RNG
compatibility baseline rather than a paired graded-sweep point. It also includes
a guarded WSL cgroup-delegation template, explicit-confirmation installer,
read-only verifier, and probe-first runbook. No host change was applied. The
strict runner now discovers and records the ext4 scratch block device instead
of assuming `/dev/sdd`.

Verification at packaging on 2026-07-11: `python -m pytest -q` passed 10 tests;
JSON and Python compile checks passed; all three shell scripts passed `bash -n`.
The read-only WSL verifier confirmed unified cgroup v2 and ext4 `/dev/sdd`, but
found only `memory pids` delegated. Promotion therefore remains blocked until
CPU and I/O are delegated and memory/CPU/I/O/cleanup probes pass.
