# Run invalidated

The process reported `1303.129 MB` peak private memory under a declared
`1024 MB` limit. The Windows Job Object did not terminate it, so this run is
invalid under the HRM safety protocol even though the child exited normally and
cleanup passed. No geometry result from this run is promoted.

The wrapper was subsequently amended to set both process and job memory limits,
abort independently on observed private-memory excess, and require a cap-breach
probe before rerunning the bridge.
