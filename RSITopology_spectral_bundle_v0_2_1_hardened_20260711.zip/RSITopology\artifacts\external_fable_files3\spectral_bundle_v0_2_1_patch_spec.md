# Spectral-Bundle Protocol v0.2.1 — Patch Specification

Status: engineering amendment to `rsi-topology-spectral-bundle-v0.2`. No gate
threshold in v0.2 is loosened; item 2 adds an equivalent cap-invariant
restatement. No model weights, no outcomes beyond the frozen synthetic
fixtures. All diagnostic numbers below were produced by an external replay of
the repository code (Python 3.11, numpy/scipy/scikit-learn current as of
2026-07-11) outside the registered enforcement wrapper; they are direction-
setting evidence only and every receipt referenced must be regenerated under
the repository's own receipt discipline before promotion.

## 1. Backfill receipt: v0.1 run under the v0.2 statistic

The sealed receipt `artifacts/sparse_bundle_control/stable_result.json` was
written before `discovery.py` began serializing
`heldout_outcome_standard_deviation` and `policy_return_uplift_standardized`.
The code and receipt are therefore out of phase, which is the same
missing-provenance shape flagged in `research_engine_input_audit.md`.

Action: replay `build_sparse_fixture()` at frozen defaults (seed 20260711,
d=384, r=32, 8 contexts) with current code; write the result as a new receipt
`artifacts/sparse_bundle_control/stable_result_v0_2_backfill.json` whose
header records the SHA-256 of the v0.1 receipt it annotates
(`1888E5B4...9216FE`) and the amendment hash of protocol v0.2.

Expected values (external replay; verify bit-level agreement on uplift and
rank, tolerance 1e-4 on Haar advantage — see item 5):

- geometry: selected band `low`, rank 32, min occupancy 1.0
- mean held-out return uplift: 0.018791772039611084 (bit-identical to v0.1)
- per-fold standardized uplift: 0.0758, 0.1453, 0.1295, 0.0969, 0.1187,
  0.1375, 0.1649, 0.1232 (contexts 00–07)
- mean standardized uplift: 0.12399 ≥ 0.10 → v0.2 policy gate PASSES
- fold dispersion note: contexts 00 and 03 fall below 0.10 individually;
  the receipt must report per-fold values, not only the mean.

Interpretive boundary: this converts the v0.1→v0.2 amendment from an argument
about units into a computation. It does not upgrade the run's evidentiary
class; the underlying run remains a synthetic control.

## 2. Cap-invariant restatement of the policy gate

External KL sweep on the frozen sparse fixture (caps 0.0125–0.4, geometry
identical across caps, KL binding in 8/8 folds at every cap):

| cap    | mean uplift | standardized | uplift/√(2·KL) |
|--------|-------------|--------------|----------------|
| 0.0125 | 0.00935     | 0.0617       | 0.390          |
| 0.025  | 0.01325     | 0.0875       | 0.391          |
| 0.05   | 0.01879     | 0.1240       | 0.392          |
| 0.1    | 0.02669     | 0.1760       | 0.394          |
| 0.2    | 0.03797     | 0.2501       | 0.395          |
| 0.4    | 0.05421     | 0.3565       | 0.399          |

Uplift scales as √KL to within 2% across a 32× cap range (linear-response
regime). The invariant `IC := standardized_uplift / √(2·KL_realized)` is
stable at ≈0.39–0.40 and fully determines the gate outcome at any cap.
Consequences, both to be recorded in the amendment reason:

- The v0.1 absolute gate (0.03 at KL=0.05) required IC ≥ 0.60 on this
  fixture and was arithmetically unreachable at the planted signal level.
  The v0.1 failure is thereby demonstrated to be a units artifact.
- The v0.2 gate (standardized 0.10 at cap 0.05) is equivalent to IC ≥ 0.316.

Action: add to the policy fold record `policy_realized_ic =
policy_return_uplift_standardized / sqrt(2 * policy_kl)` and to the summary
`mean_realized_ic`. Restate the policy gate as `mean_realized_ic ≥ 0.316`
with the KL cap retained solely as a deployment constraint, not a gate
parameter. Outcome-based cap selection remains prohibited; the sweep itself
is a synthetic-only diagnostic and must not be run against real outcomes.

## 3. Sparse fixture: geometry-noise knob

`build_sparse_fixture` constructs diagonal Laplacians in one fixed coordinate
frame; the low subspace is identical across contexts by construction, so
occupancy saturates at exactly 1.0 and the ρ=0.75 consensus threshold is
never exercised at scale. Structural, not a parameter choice.

Action: add `geometry_noise: float = 0.0` to `build_sparse_fixture`. Per
context, apply a sparse rotation confined to the first 2r coordinates
(e.g. `expm(noise * skew / sqrt(2r))` on the 2r×2r leading block, identity
elsewhere), preserving CSR structure outside the block. `noise=0.0` must
reproduce the current fixture bit-identically at the frozen seed; add a unit
test asserting this. Default remains 0.0 so existing receipts are unaffected.

## 4. Standing occupancy-calibration control

External graded-noise sweep on the dense fixture (d=48, r=12, 10 contexts,
3 seeds, seed-consistent throughout):

| noise | min occupancy | geometry | edit gate | policy std uplift |
|-------|---------------|----------|-----------|-------------------|
| 0.015 | 0.9996        | pass     | pass      | ~0.15             |
| 0.10  | 0.981         | pass     | pass      | ~0.15             |
| 0.20  | 0.925         | pass     | pass      | ~0.15             |
| 0.35  | 0.786–0.795   | pass     | pass      | ~0.15             |
| 0.50  | 0.751–0.753   | pass     | FAIL      | 0.03–0.05         |
| 0.75  | —             | FAIL (rank 0) | —    | —                 |

Finding: downstream utility collapses before the geometry gate does. At
noise 0.5 the bundle clears ρ=0.75 by ~0.002 while the edit gate fails and
policy uplift has fallen ~4×. The gate's real failure mode is
geometry-pass-with-dead-signal, not false-negative geometry. On this fixture
family the downstream-live occupancy zone is approximately [0.85, 1.0]; the
JSpace d=4 unit run (min occupancy 0.8746) sits inside it.

Actions:
- Report `consensus_occupancy_margin = min_occupancy − ρ` in every geometry
  receipt and flag margins below 0.10 as downstream-failure predictors.
  Do not raise ρ; the geometry gate is already necessary-not-sufficient and
  the noise→utility mapping is fixture-specific.
- Register the sweep (noise grid, ≥3 seeds, dense fixture now, sparse fixture
  after item 3) as a standing CPU-only control rerun whenever `discovery.py`
  or a fixture changes. Permitted under the current enforcement restrictions:
  no model weights, no caps required beyond the unit-test class.

## 5. Receipt environment pinning

External replay reproduced uplift and geometry bit-identically but drifted at
the 6th decimal on `haar_advantage` (0.22573184 vs sealed 0.22573557),
consistent with a library-version difference in the ridge solve or QR.

Action: `write_result` must record `numpy`, `scipy`, `scikit-learn`, and
Python versions plus platform string in every receipt; `pyproject.toml` pins
exact versions. Cross-version comparisons use tolerance 1e-4 on solver-derived
quantities and bit-equality on fixture-derived quantities.

## Out of scope

The resource-enforcement blocker is unchanged: items 1–5 are all unit-class
CPU runs permitted today. The one-prompt real-model benchmark still requires
CPU/I/O cgroup delegation (see `resource_enforcement_audit.md`); the
delegation drop-in path (`/etc/systemd/system/user@.service.d/delegate.conf`,
`Delegate=cpu cpuset io memory pids`, ext4-rootfs-only I/O metering,
`cgroup_no_v1=all` if hybrid) is a host change requiring explicit user
authorization and is not part of this patch.
