# Bundle Lineage: Coherence Is Not Identity

## Finding from the sealed diagnostic receipts

The occupancy calibration contains a sharp geometry-pass/utility-collapse
transition. From noise `0.35` to `0.5`, all three seeds continue to pass the
geometry gate. Rank remains `12 -> 12`, `12 -> 11`, and `12 -> 12`; minimum
occupancy falls only about `0.0384` on average and remains above `0.75`.
Nevertheless, standardized policy utility retains only about `26.6%` of its
prior value, a mean loss of `73.4%`, and the direct-edit gate flips from pass to
fail in all three seeds.

This is post hoc external diagnostic evidence, not a new registered result. It
does establish that rank plus minimum occupancy are not sufficient statistics
for downstream utility in this fixture. The mechanism is not identified by the
receipt: possibilities include a spectral identity swap, smooth rotation away
from the planted causal subspace, a band-membership crossing, or an outcome
response transition.

## Mathematical refinement

Let `P_t` be the consensus projector at perturbation scale or context `t`.
Occupancy summarizes agreement among the projectors used to construct `P_t`.
It does not say whether the coherent subspace at `t` is the same subspace that
carried useful behavior at a registered reference `P_ref`.

The missing object is a connection or lineage on the empirical spectral
bundle. Its simplest target-blind statistic is chordal overlap:

`L_t = tr(P_ref P_t) / min(rank(P_ref), rank(P_t))`.

Principal angles separate average overlap from worst-direction failure. If
`sigma_i` are the singular values of `U_ref^T U_t`, then `sigma_i^2` are
directional retention factors. Reference recall and current precision handle
rank changes separately; minimum retention catches a single lost capability
direction; mean log retention measures volume collapse.

For allocation, the soft lineage operator

`A_t = P_t P_ref P_t`

is positive semidefinite and grades current directions by reference retention.
The candidate score `x^T A_t x / ||x||^2` can be tested beside hard bundle
energy without changing the frozen policy. For edits, orthogonal Procrustes
alignment transports signed coordinates from `U_ref` into `U_t`; discovery
still emits only a normalized, hashed proposal.

This operator has a useful exact interpretation. For every `x`,
`x^T A_t x = ||P_ref P_t x||^2`, so `0 <= A_t <= P_t`. Restricted to the
current subspace, its eigenvalues are the squared cosines of the principal
angles to the reference subspace. It therefore interpolates continuously
between retained directions (`1`) and lineage-breaking directions (`0`)
without inventing a new coordinate system or requiring outcome labels.

## Why this is interesting

The current program tests whether a high-dimensional structure is internally
shared. Lineage tests whether that structure continues to denote the same
functional object. That distinction is directly relevant to self-improvement:
an RL policy should prefer changes lying in structures that are both coherent
and identity-preserving, while a disparate edit should be rejected when its
apparently stable subspace has rotated away from the registered causal anchor.

It also sharpens the AI-2040 verification critique. Compute or transparency
systems may observe stable architecture-level geometry while capability
identity migrates within it. The correct stress test is therefore not merely
whether structure remains visible, but whether the visible structure has a
verifiable lineage to the capability being governed.

## Next capped experiment

The proposal-only protocol
`protocols/spectral_bundle_lineage_followup_v0_1.json` freezes the reference
rule, target-blind features, controls, sealing requirements, and grouped
evaluation. It does not amend v0.2.1. The next enforced run must serialize these
features before outcome join and ask whether lineage adds held-out value beyond
occupancy, rank, eigengap, nuisance variables, and Jacobian visibility.
