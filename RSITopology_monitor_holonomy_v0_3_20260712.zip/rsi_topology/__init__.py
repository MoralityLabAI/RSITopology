"""Spectral-bundle discovery for bounded self-improvement experiments."""

from .discovery import (
    ConsensusBand,
    DiscoveryConfig,
    DiscoveryResult,
    discover_consensus_bands,
    evaluate_discovery,
    subspace_lineage,
)
from .jspace_bridge import load_operator_bundle, write_operator_bundle
from .holonomy import (
    GrassmannLoop,
    LoopHolonomy,
    analytic_origin_curvature,
    build_grassmann_loop,
    canonical_rotation_angles_degrees,
    evaluate_grassmann_loop,
    evaluate_perimeter_area_control,
    holonomy_phase_degrees,
    holonomy_orientation_receipt,
    holonomy_score,
    loop_holonomy,
    procrustes_transport,
    resample_subspace_frames,
)

__all__ = [
    "ConsensusBand",
    "DiscoveryConfig",
    "DiscoveryResult",
    "discover_consensus_bands",
    "evaluate_discovery",
    "subspace_lineage",
    "load_operator_bundle",
    "write_operator_bundle",
    "GrassmannLoop",
    "LoopHolonomy",
    "analytic_origin_curvature",
    "build_grassmann_loop",
    "canonical_rotation_angles_degrees",
    "evaluate_grassmann_loop",
    "evaluate_perimeter_area_control",
    "holonomy_phase_degrees",
    "holonomy_orientation_receipt",
    "holonomy_score",
    "loop_holonomy",
    "procrustes_transport",
    "resample_subspace_frames",
]
