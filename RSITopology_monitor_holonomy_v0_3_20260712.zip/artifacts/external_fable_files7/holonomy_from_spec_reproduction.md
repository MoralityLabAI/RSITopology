# From-Specification Reproduction: Monitor Holonomy Control

Method: independent reimplementation using only the prose construction in
`monitor_holonomy_insight.md` — no repository code consulted. This tests
specification completeness, which rerunning shipped code cannot.

## Matched control (exact agreement)

| quantity | doc | from-spec |
|---|---:|---:|
| commutator norm (curved) | 2.8914 | 2.8914 |
| loop phase (curved) | -62.173 deg | -62.173 deg |
| signed return (curved) | 0.466809 | 0.466809 |
| mean edge lineage (flat/curved) | 0.992571 / 0.994692 | 0.992571 / 0.994692 |
| flat loop phase / signed return | 0 deg / 1.0 | 0.000 deg / 1.000000 |
| det(H), both conditions | (not reported) | +1.000 |

Vocabulary note: the doc's "minimum edge lineage 0.990033" is min-over-edges
of worst_direction_retention (= cos^2 of the 0.1 step angle), not of mean
chordal. Reproduced once the metric is named correctly. Receipt fields should
use exact names (min_edge_worst_direction_retention) — the ambiguity is live.

## Area law (confirmed; slope is grid-dependent, curvature is not)

Closed origin-anchored loops, sides 0.02-0.2: doubling ratio 3.9907,
linear fit slope 84.34, R^2 0.999990 (doc: 83.84, R^2 0.999975). deg/area
drifts 85.36 -> 84.32 across that size range, so fitted slope depends on the
plaquette grid. Analytic origin curvature from F = P[dP_s, dP_t]P:
85.3707 deg per unit area — the exact small-loop constant. Recommend receipts
record the analytic rate as target and the fit grid as metadata.

## Recommendation: det(H) as a mandatory receipt field

H lies in O(r); coarse-step real audits can produce det(H) = -1, a
reflection — a categorically worse identity break, invisible to canonical
angles (whose meaning assumes SO(r)). Both conditions here are +1 and small
steps guarantee it, but the receipt should carry det(H) with -1 raising a
flag that supersedes the angle summary. Same spirit as the band label: a
discrete invariant the continuous statistics quotient away.

## Not verified (archive absent, second consecutive round)

Noise null (128 seeds, perimeter variance law), Haar conjugacy-class test,
spanning-tree transport implementation, the 20-test suite. The mathematics is
certified from spec; the registered machinery awaits the zip, and the
import-with-hash chain currently has a two-round gap in both directions.
