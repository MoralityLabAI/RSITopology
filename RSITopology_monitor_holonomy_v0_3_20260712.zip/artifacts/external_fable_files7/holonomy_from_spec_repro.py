# Independent from-spec reproduction of the monitor holonomy control.
# Source: monitor_holonomy_insight.md prose only. See reproduction note.
import numpy as np
from scipy.linalg import expm

def J(i, j, d=4):
    m = np.zeros((d, d)); m[i, j] = -1.0; m[j, i] = 1.0
    return m

A, B_flat, B_curv = J(0,2)+0.7*J(1,3), 0.7*J(0,2)-J(1,3), 0.7*J(0,3)-J(1,2)
U0 = np.eye(4)[:, :2]

def frame(s, t, B): return expm(s*A + t*B) @ U0

def procrustes_Q(Ua, Ub):
    W, sig, Vt = np.linalg.svd(Ub.T @ Ua)
    return W @ Vt, sig

def loop(B, side=1.0, n=10):
    st = side/n
    pts = ([(k*st,0.0) for k in range(n)] + [(side,k*st) for k in range(n)]
         + [(side-k*st,side) for k in range(n)] + [(0.0,side-k*st) for k in range(n)])
    fr = [frame(s,t,B) for s,t in pts]; fr.append(fr[0])
    H, worst, mean = np.eye(2), [], []
    for a in range(len(pts)):
        Q, sig = procrustes_Q(fr[a], fr[a+1])
        H = Q @ H; worst.append(min(sig)**2); mean.append(np.mean(sig**2))
    ang = np.degrees(np.arctan2(H[1,0], H[0,0]))
    return dict(H=H, angle=ang, det=float(np.linalg.det(H)),
                signed_return=float(np.trace(H)/2),
                min_edge_worst_direction_retention=float(min(worst)),
                mean_edge_chordal=float(np.mean(mean)))

if __name__ == "__main__":
    for name, B in (("flat", B_flat), ("curved", B_curv)):
        r = loop(B)
        print(name, {k: (round(v,6) if isinstance(v,float) else None) for k,v in r.items() if k!="H"},
              "| commutator", round(float(np.linalg.norm(A@B-B@A)),4))
